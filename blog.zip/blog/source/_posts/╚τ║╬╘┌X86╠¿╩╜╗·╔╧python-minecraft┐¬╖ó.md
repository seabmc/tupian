tags: []
categories: []
date: 2024-02-05 23:42:00
---

---

# 在X86台式机上使用Python进行Minecraft开发

## 参考文章
[在 Windows PC 上使用 Bukkit + RaspberryJuice 学习 MC 编程_mcpiwindows实现-CSDN博客](https://blog.csdn.net) 

## 正文
首先我们需要知道minecraft基于JAVA运行。要启动minecraft，我们可以去爱发电下载PCL2。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/2.png)链接：[爱发电 - PCL2下载](https://ltcat.lanzoum.com/b0aj6gsid)（提取码：pcl2）

然后我们需要把下载下来的压缩包给解压然后把PCL2.exe放到某个目录，如D：mc。

![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/1.png)

双击PCL2.exe，而后会出现PCL，最后就进去主界面。注意！！！！！！！杀毒软件如360等会报毒，我的天，github开源的东西，不可能有病毒吧？github和用户也不是傻子！！

我们点击下载，选择正式版，选择1.16.5，选择。。不说了，放图吧！
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/3.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/4.png)

点开始安装，期间可能会提示需要安装java,就下载，然后一路下一步，同意协议，一路下一步，直到安装完成。

现在去看看植物，休息一下，再继续！相信你现在已经休息好了，那我们继续吧！

现在我们需要去下载RaspberryJuice。[RaspberryJuice下载链接](https://github.com/zhuowei/RaspberryJuice/blob/master/jars/raspberryjuice-1.12.1.jar)

下载完成后，先不要管他，我们去下载MSL服务器。[MSL服务器下载链接](http://wky.ourmc.rr.nu:5244/d/home/%E5%AF%B9%E5%A4%96/MSL.exe)

不支持IPV6也没关系，后面都有度盘下载，就是有点点慢。

我们把MSL开服器复制到一个你认识的地方，如D：mc。然后双击MSL.exe打开MSL开服器，如果有更新就点更新。额，服啦，MSL服务器炸了，我们现在可以使用开服侠代替，操作基本是一样的。[开服侠下载链接](https://kaifuxia.com)
我们下载完成后把文件都解压到一个认识的地方，如D：MC。打开文件夹，点击点击开服，选择插件端，选择1.16.5。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/6.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/5.pngg)
等待下载完成。。。下载完成，现在点击主界面右下角的像设置的按钮，启动服务器，等待出现done。 然后关闭服务器，接下来的操作：关闭正版验证（如果你没正版minecraft）。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/7.png)

我们点击右下角按钮，选择打开文件夹。有一大堆文件，不要慌，镇定，有用的不多。我们打开server.properties,寻找online-mode,调成false。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/8.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/9.png)

最后我们把之前下载的插件文件扔进plugins文件夹里，回到开服侠，点击启动，此时我们去下载python和pycharm。

- Python: [Python官网](https://www.python.org)
- Pycharm: [Pycharm下载链接](https://www.jetbrains.com/pycharm/download/?section=windows)

下载安装之后一路下一步，安装完成之后打开pycharm。点击plugins,搜索Chinese,安装，重启IDE，那家伙就会变成中文。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/10.png)

此时，我们要去安装mcpi库以使用python操纵游戏世界。我们新建一个纯python文件，然后点击右上角设置按钮，选择设置，然后进行安装。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/11.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/12.png)
安装完成后就可以去PCL2启动游戏，去开服侠启动服务器，然后就是激动人心的时刻，使用PY代码操纵游戏世界！

```python
import mcpi.minecraft as minecraft
mc = minecraft.Minecraft.create()
mc.postToChat("Hello World!")
```

这就是代码。最后先进入游戏，多人游戏，直接连接，IP输127.0.0.1，进去后再在pycharm里运行代码，你就会发现，聊天框出现了hello world！恭喜你，成功了。

感谢您看到这里，接下来快去开启您的python-minecraft时光吧！

Sean
