title: 如何正确使用GitHub下载软件
author: 苦落小花MC
date: 2024-02-22 11:59:16
tags:
---
---

1. 首先，我们需要打开浏览器。
2. 输入 [github.com](https://github.com)。
    - 打不开？尝试输入 [521github.com](https://521github.com)。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/16.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/17.png)
3. 在搜索框输入你要找的开源软件，如：GKD, TVbox......。
    - 会有很多结果，一般第一个就是你要找的软件。
4. 点击标题，进入开源项目主页。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/18.png)
5. 点击 **Releases**。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/19.png)
6. 点击最新版本（最上面那个）。
7. 点击 **Assets**。
![](https://raw.githubusercontent.com/seabmc/tupian/main/20.png)
8. 根据你的设备选择对应的安装包。
    - 安卓选择 APK，Windows选择 msi 或者 exe。
9. 点击文件名进行下载。
10. 下载完成后安装即可使用！
