---
title: 我的WSA刷咸鱼
date: 2024-02-05 10:02:33
tags:
---
<!--more-->
# 使用指南：在 Windows 系统上安装 WSA 安卓子系统

1. 首先，访问 [WSABuilds releases 页面](https://github.com/MustardChef/WSABuilds/releases)，找到适用于 Win10 x64 的版本。找到名为 `WSA_2311.40000.4.0_x64_Release-Nightly-NoGApps-RemovedAmazon_Windows_10.7z` 的文件，点击文件名下载，下载可能会比较慢。

2. 下载完成后，将压缩包解压到 D 盘。

3. 打开解压后的压缩包，将里面的 `WSA` 文件夹拖出来放到 D 盘。

4. 打开 `run.bat` 文件，系统会自动进行安装。

5. 注意，可能会遇到需要启用虚拟化的问题。可以通过搜索电脑主板型号+如何开启虚拟化来找到相关教程。

6. 在控制面板中启用以下功能：Hyper-V 和虚拟机平台，然后重启电脑。

7. 运行 `run.bat` 文件，即可安装 WSA 安卓子系统。

8. 安装完成后，还不能正常安装 APP，需要下载 [WSA 工具箱](https://apps.microsoft.com/detail/9PPSP2MKVTGT)。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/14.png)
9. 安装完成后，进入 WSA 设置，点击关闭，等待关闭完成后再点击文件重启。

10. 重启完成后打开文件窗口，回到 WSA 工具箱，点击重试尝试连接。

11. 等待几秒，会弹出是否允许 ADB 调试，点击始终允许。

12. 工具箱会提示连接成功，可以在安装 APP 里安装 APK。

13. 在手机上打包咸鱼 APK，可以使用长按分享或者 MT 管理器https://mt2.cn/download/进行打包。

14. 打包完成后，使用 QQ 发送到电脑上，然后在 WSA 工具箱里安装。

15. 安装完成后切换到 APP 管理，启动，滑动认证，然后登录。

16. 你会发现你得到了一个可以在电脑上完美运行的咸鱼 APP。
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/15.png)
17. 开始享受吧，哈哈哈。

感谢阅读！  
Sean
备用链接：https://pan.baidu.com/s/1NySxWRnHSxxR__rgUe7HoA?pwd=xhmb 
提取码：xhmb
