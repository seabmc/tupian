title: IBMlinuxONE运行MC服务器
author: 苦落小花MC
date: 2024-02-24 10:52:44
tags:
---
```markdown
# 在IBMLinuxONE上搭建Minecraft服务器

众所周知，IBMLinuxONE拥有2H4G的超强配置，但是由于其特殊的架构S39X，软件支持相对较少。尽管这台机器在架构上存在一些问题，但在其他方面表现还不错。因此，我想知道是否可以安装mcsm、docker、JAVA，并将其用于运行Minecraft服务器呢？让我们开始理论上的探讨，实践也将随之展开！

## 参考链接
[点击查看参考链接](blog.shiina.fun/2023/09/12/linuxone安装1panel建站-2/)

## 安装Docker
首先，按照下面的步骤进行操作：
```bash
wget https://download.docker.com/linux/static/stable/s390x/docker-18.06.3-ce.tgz
tar zxf docker-18.06.3-ce.tgz
mv docker/* /usr/bin/ && rm -rf docker*
chown root:root /usr/bin/docker*
chmod +x /usr/bin/docker*
nohup dockerd 2>&1 &
docker -v
```

安装完成后，你应该看到以下输出：
```
Docker version 18.06.3-ce, build d7080c1
```

接着执行：
```bash
apt install docker.io
```

再次检查Docker版本：
```
docker -v
Docker version 24.0.5, build 24.0.5-0ubuntu1~22.04.1
```

PS：在执行 `apt install docker.io` 时，我遇到了404错误，但过了一会儿再试就正常了。报错是由于UBUNTU的网站出现问题。6.。

## 安装MCSM
接下来，安装MCSM：
```bash
sudo wget -qO- https://gitee.com/mcsmanager/script/raw/master/setup_cn.sh | bash
```

等待安装完成后，在浏览器中输入 `http://你的LINUXONEIP:23333`，进入面板。然后设置账号密码，进行节点管理和镜像管理。新增一个镜像，创建OPENJDK17镜像。等待镜像创建完成后，就可以直接开始创建服务器进行测试。

我搭建了一个1.20.1原版Spigot服务器，延迟稳定在250MS左右，没有出现卡顿和掉线，游戏体验很稳定！
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/24.png)
![alt 属性文本](https://raw.githubusercontent.com/seabmc/tupian/main/25.png)
然而，晚上到了，网络高峰期开始，服务器开始出现卡顿。虽然延迟开始变得不稳定，但没有出现掉线。这种表现真的有点让人难以置信，甚至比我另一台付费服务器的表现还要好（就不点名了，马上就到期了）。
```