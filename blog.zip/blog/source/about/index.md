---
title: about
date: 2024-02-09 20:11:35
---
这是一个普普通通的初二学生的博客
使用了hexo,hexo-admin,next
想要同款的可以发邮件到klxh@ourmc.rr.nu
会免费给你调较好的ZIP
